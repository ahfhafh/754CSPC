# memsim

starter code for Assignment 5

# test files:
```
$ wc -l *.txt
      17 test1.txt
       1 test2.txt
       1 test3.txt
   68807 test4.txt
 1000000 test5.txt
 1000000 test6.txt
 2068826 total
```
---
# My results, using dynamic array - entirely unoptimized, very $`O(n^2)`$
```
$ /bin/time -f 'time: %e s' timeout 15 ./memsim 123 < ../memsim/test1.txt
pages requested: 57
largest free chunk: 110
time: 0.00 s

$ /bin/time -f 'time: %e s' timeout 15 ./memsim 321 < ../memsim/test2.txt
pages requested: 16
largest free chunk: 136
time: 0.00 s

$ /bin/time -f 'time: %e s' timeout 15 ./memsim 111 < ../memsim/test3.txt
pages requested: 0
largest free chunk: 0
time: 0.00 s

$ /bin/time -f 'time: %e s' timeout 15 ./memsim 222 < ../memsim/test4.txt
pages requested: 896
largest free chunk: 1000
time: 2.13 s

$ /bin/time -f 'time: %e s' timeout 15 ./memsim 333 < ../memsim/test5.txt
pages requested: 121597
largest free chunk: 9445200
time: 11.85 s

$ /bin/time -f 'time: %e s' timeout 15 ./memsim 606 < ../memsim/test6.txt

... did not finish under 15s

```

# My results - using more advanced data-structures, $`n log n`$

```
$ /bin/time -f 'time: %e s' timeout 15 ./memsim3 123 < ../memsim/test1.txt
pages requested: 57
largest free chunk: 110
time: 0.00 s

$ /bin/time -f 'time: %e s' timeout 15 ./memsim3 321 < ../memsim/test2.txt
pages requested: 16
largest free chunk: 136
time: 0.00 s

$ /bin/time -f 'time: %e s' timeout 15 ./memsim3 111 < ../memsim/test3.txt
pages requested: 0
largest free chunk: 0
time: 0.00 s

$ /bin/time -f 'time: %e s' timeout 15 ./memsim3 222 < ../memsim/test4.txt
pages requested: 896
largest free chunk: 1000
time: 0.01 s

$ /bin/time -f 'time: %e s' timeout 15 ./memsim3 333 < ../memsim/test5.txt
pages requested: 121597
largest free chunk: 9445200
time: 0.85 s

$ /bin/time -f 'time: %e s' timeout 15 ./memsim3 606 < ../memsim/test6.txt
pages requested: 2682392
largest free chunk: 9996
time: 1.49 s
```
